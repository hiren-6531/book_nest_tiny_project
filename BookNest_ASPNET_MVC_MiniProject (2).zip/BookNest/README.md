# BookNest - Online Bookstore

**ASP.NET MVC 5 Mini Project**

## Project Title
**BookNest** – A simple online bookstore web application.

## Description
BookNest is a mini project developed using ASP.NET MVC 5 (.NET Framework).  
It allows users to browse books, view details, filter by category, and add books to a shopping cart.

## Pages Included
1. **Home** – Welcome page with featured books
2. **Books** – List of all books with category filter
3. **Book Details** – Full information of a selected book
4. **Cart** – View and manage cart items (session based)
5. **About Us** – Information about the project
6. **Contact Us** – Contact form

## Features
- Clean navigation across all pages
- Book listing with category filter (Programming, Self-Help, Fiction, Finance)
- Book details page
- Add to Cart / Remove from Cart using Session
- Contact form with basic validation
- Responsive design

## Technologies Used
- ASP.NET MVC 5
- C#
- HTML5 + CSS3
- Razor View Engine
- Session State (for cart)

## How to Run
1. Open `BookNest.sln` in Visual Studio
2. Restore NuGet packages if prompted
3. Press **F5** or click **IIS Express** to run
4. The website will open in your browser

## Project Structure
```
BookNest/
├── Controllers/     (Home, Books, Cart)
├── Models/          (Book, CartItem, BookRepository)
├── Views/           (Home, Books, Cart, Shared)
├── Content/         (Site.css)
└── App_Start/       (RouteConfig, etc.)
```

## Note
This project uses an in-memory list of books (no database required).  
This makes it easy to run and demonstrate without extra setup.

---
Faculty of IT & Computer Science  
ASP.NET Mini Project
