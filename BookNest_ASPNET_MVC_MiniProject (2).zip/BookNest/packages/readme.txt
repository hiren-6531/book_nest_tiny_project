NuGet packages will be restored by Visual Studio
