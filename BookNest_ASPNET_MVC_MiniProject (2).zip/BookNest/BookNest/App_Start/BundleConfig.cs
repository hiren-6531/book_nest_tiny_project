using System.Web.Optimization;

namespace BookNest
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            // Minimal - we are using custom CSS
        }
    }
}
