using System.Collections.Generic;
using System.Linq;

namespace BookNest.Models
{
    // Simple in-memory data store so the project runs without database
    public static class BookRepository
    {
        private static List<Book> books = new List<Book>
        {
            new Book { Id = 1, Title = "Clean Code", Author = "Robert C. Martin", Category = "Programming", Price = 450, Description = "A handbook of agile software craftsmanship. Learn how to write clean, maintainable code.", ImageUrl = "https://via.placeholder.com/200x280?text=Clean+Code", Stock = 25 },
            new Book { Id = 2, Title = "The Pragmatic Programmer", Author = "Andrew Hunt", Category = "Programming", Price = 520, Description = "Classic guide to software development best practices and career growth.", ImageUrl = "https://via.placeholder.com/200x280?text=Pragmatic", Stock = 18 },
            new Book { Id = 3, Title = "Atomic Habits", Author = "James Clear", Category = "Self-Help", Price = 380, Description = "Tiny changes that deliver remarkable results. Build better habits every day.", ImageUrl = "https://via.placeholder.com/200x280?text=Atomic+Habits", Stock = 40 },
            new Book { Id = 4, Title = "Rich Dad Poor Dad", Author = "Robert Kiyosaki", Category = "Finance", Price = 299, Description = "What the rich teach their kids about money that the poor and middle class do not.", ImageUrl = "https://via.placeholder.com/200x280?text=Rich+Dad", Stock = 35 },
            new Book { Id = 5, Title = "Introduction to Algorithms", Author = "Cormen et al.", Category = "Programming", Price = 890, Description = "Comprehensive textbook on algorithms used worldwide in computer science courses.", ImageUrl = "https://via.placeholder.com/200x280?text=Algorithms", Stock = 12 },
            new Book { Id = 6, Title = "The Alchemist", Author = "Paulo Coelho", Category = "Fiction", Price = 250, Description = "A magical story about following your dreams and listening to your heart.", ImageUrl = "https://via.placeholder.com/200x280?text=Alchemist", Stock = 50 },
            new Book { Id = 7, Title = "Deep Work", Author = "Cal Newport", Category = "Self-Help", Price = 420, Description = "Rules for focused success in a distracted world. Master the skill of deep work.", ImageUrl = "https://via.placeholder.com/200x280?text=Deep+Work", Stock = 22 },
            new Book { Id = 8, Title = "ASP.NET MVC 5", Author = "Jon Galloway", Category = "Programming", Price = 650, Description = "Practical guide to building web applications with ASP.NET MVC 5.", ImageUrl = "https://via.placeholder.com/200x280?text=ASP.NET+MVC", Stock = 15 }
        };

        public static List<Book> GetAll()
        {
            return books;
        }

        public static Book GetById(int id)
        {
            return books.FirstOrDefault(b => b.Id == id);
        }

        public static List<Book> GetByCategory(string category)
        {
            if (string.IsNullOrEmpty(category) || category == "All")
                return books;
            return books.Where(b => b.Category == category).ToList();
        }

        public static List<string> GetCategories()
        {
            return books.Select(b => b.Category).Distinct().OrderBy(c => c).ToList();
        }

        public static List<Book> GetFeatured(int count = 4)
        {
            return books.Take(count).ToList();
        }
    }
}
