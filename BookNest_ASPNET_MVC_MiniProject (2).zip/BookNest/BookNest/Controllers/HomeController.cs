using System.Web.Mvc;
using BookNest.Models;

namespace BookNest.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var featuredBooks = BookRepository.GetFeatured(4);
            return View(featuredBooks);
        }

        public ActionResult About()
        {
            ViewBag.Message = "About BookNest - Your online bookstore";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Contact us for any queries";
            return View();
        }

        [HttpPost]
        public ActionResult Contact(string name, string email, string message)
        {
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(message))
            {
                ViewBag.Error = "Please fill all fields.";
                return View();
            }

            // In real project we would save to database or send email
            ViewBag.Success = "Thank you " + name + "! Your message has been received. We will contact you soon.";
            return View();
        }
    }
}
