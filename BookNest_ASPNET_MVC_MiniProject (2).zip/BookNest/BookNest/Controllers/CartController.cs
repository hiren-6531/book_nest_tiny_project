using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using BookNest.Models;

namespace BookNest.Controllers
{
    public class CartController : Controller
    {
        private const string CartSessionKey = "Cart";

        private List<CartItem> GetCart()
        {
            var cart = Session[CartSessionKey] as List<CartItem>;
            if (cart == null)
            {
                cart = new List<CartItem>();
                Session[CartSessionKey] = cart;
            }
            return cart;
        }

        // GET: Cart
        public ActionResult Index()
        {
            var cart = GetCart();
            ViewBag.Total = cart.Sum(c => c.Total);
            return View(cart);
        }

        // POST: Cart/Add
        public ActionResult Add(int id)
        {
            var book = BookRepository.GetById(id);
            if (book == null)
            {
                return HttpNotFound();
            }

            var cart = GetCart();
            var existing = cart.FirstOrDefault(c => c.BookId == id);

            if (existing != null)
            {
                existing.Quantity++;
            }
            else
            {
                cart.Add(new CartItem
                {
                    BookId = book.Id,
                    Title = book.Title,
                    Author = book.Author,
                    Price = book.Price,
                    Quantity = 1
                });
            }

            Session[CartSessionKey] = cart;
            TempData["Message"] = "\"" + book.Title + "\" added to cart successfully!";
            return RedirectToAction("Index");
        }

        // POST: Cart/Remove
        public ActionResult Remove(int id)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(c => c.BookId == id);
            if (item != null)
            {
                cart.Remove(item);
                Session[CartSessionKey] = cart;
                TempData["Message"] = "Item removed from cart.";
            }
            return RedirectToAction("Index");
        }

        // POST: Cart/Clear
        public ActionResult Clear()
        {
            Session[CartSessionKey] = new List<CartItem>();
            TempData["Message"] = "Cart cleared.";
            return RedirectToAction("Index");
        }
    }
}
