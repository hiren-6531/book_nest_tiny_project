using System.Web.Mvc;
using BookNest.Models;

namespace BookNest.Controllers
{
    public class BooksController : Controller
    {
        // GET: Books
        public ActionResult Index(string category = "All")
        {
            ViewBag.Categories = BookRepository.GetCategories();
            ViewBag.SelectedCategory = category;
            var books = BookRepository.GetByCategory(category);
            return View(books);
        }

        // GET: Books/Details/5
        public ActionResult Details(int id)
        {
            var book = BookRepository.GetById(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }
    }
}
